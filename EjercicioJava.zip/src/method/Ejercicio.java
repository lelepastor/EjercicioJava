package method;


public class Ejercicio {
	
	public static final Double PI = 3.14;
	

	public static void main(String[] args) {
				
		// Variables
		
		// Inicio
		System.out.println(numeroSolucionesEcuacionSegundoGrado(2,1,3));
				
				
	}
	
	public static int numeroSolucionesEcuacionSegundoGrado(int a, int b, int c) {
		int resul;
		resul=b*b - 4*a*c;
		if (resul==0) {
			return 1;
		}else if (resul <0) {
			return 0;
		}else if(a ==0) {
			return -1;
		}else {
			return 2;
		}
	}
	
	public static Double solucionSumaEcuacionSegundoGrado(int a, int b, int c) {
		int result;
		result=(int)Math.sqrt(b*b - 4*a*c);
	}
	
	
	
	public static Double solucionRestaEcuacionSegundoGrado(int a, int b, int c) {
		
	}	
	
	public static Double areaCirculo(Double r) {
		
	}
	
	public static Double longitudCirculo(Double r) {
		
	}
	
	public static boolean esMultiplo(int a, int b) {
		
	}
	
	public static int horaMayor(int hora1, int min1, int seg1, int hora2, int min2, int seg2) {
		
		
	}
	
	public static int segundosEntre(int hora1, int min1, int seg1, int hora2, int min2, int seg2) {
				
		
	}
	
	public static int maximoComunDivisor(int a, int b) {
		
	}
	
	public static int minimoComunMultiplo(int a, int b) {
		
	}
	
	public static String binario(int num) {
		
	}
	
	public static int decimal(String num) {
		
	}
}
